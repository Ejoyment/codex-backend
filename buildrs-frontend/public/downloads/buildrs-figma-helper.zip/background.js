/**
 * Buildrs Figma Helper - background service worker.
 *
 * Figma has no public API that lists the files a user can open, so this
 * extension reads the user's own Figma "recent files" list from a signed-in
 * www.figma.com tab (same-origin fetch, their cookies) and posts only file
 * keys, names, thumbnails and modified dates to Buildrs. The user's Figma
 * session never leaves the browser, and the Buildrs JWT is only used to call
 * the Buildrs sync endpoint.
 */
const DEFAULTS = {
  apiBase: 'https://codex-backend-7utu.onrender.com',
  frontendBase: 'https://buildrshq.dev',
};

const SYNC_ALARM = 'buildrs-figma-sync';
const SYNC_INTERVAL_MINUTES = 15;
const FIGMA_RECENT_FILES_URL = 'https://www.figma.com/api/recent_files?org_id=null';
const MAX_FILES = 200;

function normalizeBase(raw) {
  const value = String(raw || '').trim();
  if (!value) return '';
  try {
    const url = new URL(value);
    if (!['https:', 'http:'].includes(url.protocol)) return '';
    return `${url.origin}${url.pathname.replace(/\/+$/, '').replace(/\/api$/i, '')}`.replace(/\/+$/, '');
  } catch (error) {
    return '';
  }
}

async function getSettings() {
  const stored = await chrome.storage.local.get([
    'apiBase',
    'frontendBase',
    'authToken',
    'helperSyncedAt',
    'lastSyncError',
    'fileCount',
  ]);
  return {
    apiBase: normalizeBase(stored.apiBase) || DEFAULTS.apiBase,
    frontendBase: normalizeBase(stored.frontendBase) || DEFAULTS.frontendBase,
    authToken: stored.authToken || null,
    helperSyncedAt: stored.helperSyncedAt || null,
    lastSyncError: stored.lastSyncError || null,
    fileCount: Number(stored.fileCount) || 0,
  };
}

async function recordError(message) {
  await chrome.storage.local.set({ lastSyncError: String(message || 'Sync failed') });
  return { ok: false, error: String(message || 'Sync failed') };
}

function waitForTabComplete(tabId, timeoutMs = 25000) {
  return new Promise((resolve, reject) => {
    const startedAt = Date.now();
    const check = () => {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (tab.status === 'complete') {
          resolve(tab);
          return;
        }
        if (Date.now() - startedAt > timeoutMs) {
          reject(new Error('Figma took too long to load. Open figma.com, then try again.'));
          return;
        }
        setTimeout(check, 500);
      });
    };
    check();
  });
}

async function getFigmaTab() {
  const tabs = await chrome.tabs.query({ url: ['https://www.figma.com/*'] });
  if (tabs.length) {
    return { tab: tabs.find((tab) => tab.active) || tabs[0], created: false };
  }
  const tab = await chrome.tabs.create({ url: 'https://www.figma.com/files/', active: false });
  return { tab, created: true };
}

// Runs inside the figma.com tab. Same-origin fetch means the request carries
// the user's existing Figma cookies; nothing is copied out of the page.
async function fetchRecentFilesInPage(url) {
  const headers = { accept: 'application/json', 'x-csrf-bypass': 'yes' };
  const tsid = document.cookie.match(/(?:^|;\s*)tsid=([^;]+)/);
  if (tsid) headers.tsid = decodeURIComponent(tsid[1]);

  let response = await fetch(url, { credentials: 'include', headers });
  let text = await response.text();
  if (!response.ok) {
    response = await fetch(url, { credentials: 'include' });
    text = await response.text();
  }

  let json = null;
  try {
    json = JSON.parse(text);
  } catch (error) {
    json = null;
  }
  return {
    ok: response.ok,
    status: response.status,
    json,
    sample: text.slice(0, 300),
  };
}

// Recursively search a parsed JSON value for a Figma DOCUMENT root node.
// Figma's web API wraps the document at varying depths and keys; walking the
// object tree directly is more robust than guessing shallow paths.
function findDocumentNode(value, depth = 0) {
  if (depth > 12) return null;
  if (value && typeof value === 'object') {
    if (value.type === 'DOCUMENT' && Array.isArray(value.children)) return value;
    if (value.document && typeof value.document === 'object') {
      const found = findDocumentNode(value.document, depth + 1);
      if (found) return found;
    }
    if (value.file && typeof value.file === 'object') {
      const found = findDocumentNode(value.file, depth + 1);
      if (found) return found;
    }
    if (value.meta && typeof value.meta === 'object') {
      const found = findDocumentNode(value.meta, depth + 1);
      if (found) return found;
    }
    if (value.result && typeof value.result === 'object') {
      const found = findDocumentNode(value.result, depth + 1);
      if (found) return found;
    }
    if (value.data && typeof value.data === 'object') {
      const found = findDocumentNode(value.data, depth + 1);
      if (found) return found;
    }
    for (const key of Object.keys(value)) {
      const found = findDocumentNode(value[key], depth + 1);
      if (found) return found;
    }
  }
  return null;
}

async function fetchFileInPage(fileKey) {
  for (const depth of [2, 1, null]) {
    const url = depth
      ? `https://www.figma.com/api/files/${encodeURIComponent(fileKey)}?depth=${depth}`
      : `https://www.figma.com/api/files/${encodeURIComponent(fileKey)}`;

    const headers = { accept: 'application/json', 'x-csrf-bypass': 'yes' };
    const tsid = document.cookie.match(/(?:^|;\s*)tsid=([^;]+)/);
    if (tsid) headers.tsid = decodeURIComponent(tsid[1]);

    let response;
    try {
      response = await fetch(url, { credentials: 'include', headers });
    } catch (error) {
      continue;
    }

    let text;
    try { text = await response.text(); } catch { continue; }

    let json = null;
    try { json = JSON.parse(text); } catch { json = null; }

    // Figma sometimes embeds an error status inside a 200 response.
    if (json && typeof json.status === 'number' && json.status >= 400) {
      return { ok: false, status: json.status, json, sample: text.slice(0, 300) };
    }

    // Figma's web API nests the document at varying depths. Search recursively
    // for a DOCUMENT root node instead of guessing shallow paths.
    const doc = findDocumentNode(json);

    if (doc) {
      return {
        ok: response.ok,
        status: response.status,
        json,
        sample: text.slice(0, 300),
        document: doc,
      };
    }
    // Try the next depth value if no document node was found.
  }

  return { ok: false, status: 0, json: null, sample: '', document: null };
}

/**
 * Runs inside the figma.com tab. Returns one frame's full subtree, read with
 * the user's own Figma session. This is what lets Buildrs convert a frame or
 * hand it to an agent without any OAuth file scope.
 */
async function fetchNodeInPage(fileKey, nodeId) {
  const headers = { accept: 'application/json', 'x-csrf-bypass': 'yes' };
  const tsid = document.cookie.match(/(?:^|;\s*)tsid=([^;]+)/);
  if (tsid) headers.tsid = decodeURIComponent(tsid[1]);

  const wanted = String(nodeId);
  const FIELD_NAMES = [
    'name', 'visible', 'opacity', 'blendMode', 'isMask', 'clipsContent',
    'rotation', 'cornerRadius', 'rectangleCornerRadii', 'cornerSmoothing',
    'absoluteBoundingBox', 'absoluteRenderBounds', 'size',
    'layoutMode', 'layoutWrap', 'itemSpacing', 'counterAxisSpacing',
    'paddingLeft', 'paddingRight', 'paddingTop', 'paddingBottom',
    'primaryAxisAlignItems', 'counterAxisAlignItems',
    'primaryAxisSizingMode', 'counterAxisSizingMode',
    'layoutSizingHorizontal', 'layoutSizingVertical',
    'layoutGrow', 'layoutAlign', 'layoutPositioning', 'constraints',
    'fills', 'strokes', 'strokeWeight', 'strokeAlign', 'strokeDashes',
    'effects', 'characters', 'style',
    'textAlignHorizontal', 'textAlignVertical', 'lineHeight', 'letterSpacing',
    'componentKey', 'componentId', 'componentProperties', 'isAsset',
  ];

  function copyJson(value, depth = 0) {
    if (value === null) return null;
    const type = typeof value;
    if (type === 'string') return value.slice(0, 4000);
    if (type === 'number') return Number.isFinite(value) ? value : null;
    if (type === 'boolean') return value;
    if (type !== 'object' || depth > 8) return null;
    if (Array.isArray(value)) return value.slice(0, 40).map((entry) => copyJson(entry, depth + 1));
    const copy = {};
    for (const key of Object.keys(value)) {
      if (key === '__proto__' || key === 'constructor' || key === 'prototype') continue;
      const entry = copyJson(value[key], depth + 1);
      if (entry !== null || value[key] === null) copy[key] = entry;
    }
    return copy;
  }

  function trimNode(node, depth = 0) {
    if (!node || typeof node !== 'object' || depth > 40) return null;
    const id = typeof node.id === 'string' ? node.id.slice(0, 200) : null;
    const type = typeof node.type === 'string' ? node.type.slice(0, 40) : null;
    if (!id || !type) return null;
    const clean = { id, type };
    for (const field of FIELD_NAMES) {
      if (!(field in node)) continue;
      const value = node[field];
      if (typeof value === 'string') clean[field] = value.slice(0, 4000);
      else if (typeof value === 'number') { if (Number.isFinite(value)) clean[field] = value; }
      else if (typeof value === 'boolean') clean[field] = value;
      else if (value && typeof value === 'object') {
        const copied = copyJson(value);
        if (copied !== null) clean[field] = copied;
      }
    }
    if (!clean.name) clean.name = type === 'CANVAS' ? 'Page' : 'Untitled layer';
    if (Array.isArray(node.children) && depth < 40) {
      const children = node.children.slice(0, 300).map((child) => trimNode(child, depth + 1)).filter(Boolean);
      if (children.length) clean.children = children;
    }
    return clean;
  }

  function findNode(value, depth = 0) {
    if (!value || typeof value !== 'object' || depth > 40) return null;
    if (String(value.id) === wanted && (typeof value.type === 'string')) return value;
    for (const key of Object.keys(value)) {
      const found = findNode(value[key], depth + 1);
      if (found) return found;
    }
    return null;
  }

  async function readJson(response) {
    const text = await response.text();
    try {
      return { ok: response.ok, status: response.status, json: JSON.parse(text) };
    } catch (error) {
      return { ok: false, status: response.status, json: null, sample: text.slice(0, 200) };
    }
  }

  // 1. Node-scoped endpoint, mirroring the REST `/files/:key/nodes` shape.
  try {
    const response = await fetch(
      `https://www.figma.com/api/files/${encodeURIComponent(fileKey)}/nodes?ids=${encodeURIComponent(nodeId)}`,
      { credentials: 'include', headers }
    );
    const parsed = await readJson(response);
    if (parsed.ok && parsed.json) {
      const entry = parsed.json.nodes?.[wanted]
        || parsed.json.nodes?.[wanted.replace(':', '-')]
        || parsed.json.nodes?.[wanted.replace('-', ':')];
      const node = entry?.document || findNode(parsed.json);
      if (node) {
        return { ok: true, status: parsed.status, fileName: parsed.json.name || null, node: trimNode(node) };
      }
    }
  } catch (error) {
    // Fall through to the whole-file document.
  }

  // 2. Whole-file document (no depth limit), then locate the frame.
  try {
    const response = await fetch(
      `https://www.figma.com/api/files/${encodeURIComponent(fileKey)}`,
      { credentials: 'include', headers }
    );
    const parsed = await readJson(response);
    if (parsed.ok && parsed.json) {
      const node = findNode(parsed.json);
      if (node) {
        return {
          ok: true,
          status: parsed.status,
          fileName: parsed.json.name || parsed.json.file?.name || null,
          node: trimNode(node),
        };
      }
    }
  } catch (error) {
    // Reported below.
  }

  return {
    ok: false,
    status: 0,
    node: null,
    error: 'Figma did not return that frame. Open the file in Figma once, then try again.',
  };
}

function mapRecentFiles(payload) {
  const list = payload?.meta?.recent_files || payload?.recent_files || payload?.files;
  if (!Array.isArray(list)) {
    throw new Error('Figma did not return your recent files. Open figma.com, make sure you are signed in, then try again.');
  }

  const seen = new Set();
  const files = [];
  for (const item of list) {
    const key = String(item?.key || item?.file_key || '').trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    files.push({
      key,
      name: item?.name || item?.file_name || 'Untitled file',
      thumbnail_url: item?.thumbnail_url || item?.thumbnailUrl || null,
      last_modified: item?.last_modified || item?.lastModified || null,
    });
    if (files.length >= MAX_FILES) break;
  }
  return files;
}

async function readFigmaRecentFiles() {
  const { tab, created } = await getFigmaTab();
  if (!tab?.id) throw new Error('Could not open Figma in this browser.');

  try {
    await waitForTabComplete(tab.id);
    let injection;
    try {
      [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: fetchRecentFilesInPage,
        args: [FIGMA_RECENT_FILES_URL],
      });
    } catch (error) {
      throw new Error('Could not read Figma. Open figma.com in a tab, sign in, then try again.');
    }

    const result = injection?.result;
    if (!result) throw new Error('Could not read Figma. Open figma.com in a tab, sign in, then try again.');
    if (!result.ok) {
      if (result.status === 401 || result.status === 403) {
        throw new Error('Figma needs you to sign in. Open figma.com, sign in, then sync again.');
      }
      throw new Error(`Figma returned ${result.status}. Open figma.com once, then try again.`);
    }
    return mapRecentFiles(result.json);
  } finally {
    if (created && tab.id) {
      chrome.tabs.remove(tab.id, () => void chrome.runtime.lastError);
    }
  }
}

let activeSync = null;

async function doSync() {
  const settings = await getSettings();
  if (!settings.authToken) {
    return recordError('Open Buildrs and sign in, then click Sync now.');
  }

  let files;
  try {
    files = await readFigmaRecentFiles();
  } catch (error) {
    return recordError(error.message);
  }

  let response;
  try {
    response = await fetch(`${settings.apiBase}/api/figma/files/sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${settings.authToken}`,
      },
      body: JSON.stringify({ files }),
    });
  } catch (error) {
    return recordError(`Could not reach Buildrs at ${settings.apiBase}.`);
  }

  const data = await response.json().catch(() => ({}));
  if (response.status === 401) {
    await chrome.storage.local.remove('authToken');
    return recordError('Buildrs session expired. Open Buildrs and sign in again.');
  }
  if (!response.ok || !data.success) {
    return recordError(data.message || `Buildrs sync failed (${response.status}).`);
  }

  const syncedAt = data.syncedAt || new Date().toISOString();
  const count = Array.isArray(data.files) ? data.files.length : files.length;
  await chrome.storage.local.set({
    helperSyncedAt: syncedAt,
    lastSyncError: null,
    fileCount: count,
  });
  return { ok: true, count, syncedAt };
}

function syncNow() {
  if (activeSync) return activeSync;
  activeSync = doSync().finally(() => { activeSync = null; });
  return activeSync;
}

async function getFile(fileKey) {
  console.log('Helper: Fetching file', fileKey);
  const { tab, created } = await getFigmaTab();
  if (!tab?.id) throw new Error('Could not open Figma in this browser.');

  try {
    await waitForTabComplete(tab.id, 45000);

    let lastError;
    let injection;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        [injection] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: fetchFileInPage,
          args: [fileKey],
        });
        console.log('Helper: Injection result (attempt', attempt, '):', injection?.result);
        break;
      } catch (error) {
        lastError = error;
        console.error('Helper: Scripting error (attempt', attempt, '):', error);
        if (attempt < 2) await new Promise((r) => setTimeout(r, 1000));
      }
    }

    if (!injection) {
      throw new Error('Could not inject into Figma. Reload the Buildrs Figma Helper extension at chrome://extensions, then try again.');
    }

    const result = injection?.result;
    if (!result) throw new Error('Figma did not respond. Make sure you are signed in to figma.com, then try again.');
    if (!result.ok) {
      console.error('Helper: Figma returned error', result.status, result.sample);
      if (result.status === 403) {
        throw new Error('Figma denied access to this file. Open it once in a Figma tab, then try again.');
      }
      throw new Error(`Figma returned ${result.status}.`);
    }

    const file = result.json;
    const document = result.document || file?.document;
    if (!document) {
      throw new Error('Figma did not return file data.');
    }

    return {
      name: result.json?.name || file?.name || 'Untitled file',
      lastModified: result.json?.lastModified || file?.lastModified || null,
      editorType: result.json?.editorType || file?.editorType || null,
      pages: extractPagesAndFrames(document),
    };
  } finally {
    if (created && tab.id) {
      chrome.tabs.remove(tab.id, () => void chrome.runtime.lastError);
    }
  }
}

function extractPagesAndFrames(document) {
  const pages = [];
  if (!document?.children) return pages;

  for (const page of document.children) {
    if (page.type !== 'CANVAS') continue;
    const frames = [];
    if (page.children) {
      for (const node of page.children) {
        if (node.type === 'FRAME' || node.type === 'SECTION' || node.type === 'COMPONENT') {
          frames.push({
            id: node.id,
            name: node.name,
            type: node.type,
            width: node.absoluteBoundingBox?.width || 0,
            height: node.absoluteBoundingBox?.height || 0,
            // Figma's web payloads sometimes include a render; otherwise the
            // frame card falls back to its size/type.
            thumbnailUrl: node.thumbnail_url || node.thumbnailUrl || null,
          });
        }
      }
    }
    pages.push({
      id: page.id,
      name: page.name,
      frames,
    });
  }
  return pages;
}

// Full frame payloads are only re-read when the user opens the same frame
// again within a few minutes; the file document can be large.
const NODE_CACHE_TTL_MS = 5 * 60 * 1000;
const nodeCache = new Map();

async function getNode(fileKey, nodeId) {
  const cacheKey = `${fileKey}:${nodeId}`;
  const cached = nodeCache.get(cacheKey);
  if (cached && Date.now() - cached.at < NODE_CACHE_TTL_MS) return cached.data;

  const { tab, created } = await getFigmaTab();
  if (!tab?.id) throw new Error('Could not open Figma in this browser.');

  try {
    await waitForTabComplete(tab.id, 45000);
    let injection;
    try {
      [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: fetchNodeInPage,
        args: [fileKey, nodeId],
      });
    } catch (error) {
      throw new Error('Could not read Figma. Reload the Buildrs Figma Helper at chrome://extensions, then try again.');
    }

    const result = injection?.result;
    if (!result) throw new Error('Figma did not respond. Make sure you are signed in to figma.com, then try again.');
    if (!result.ok || !result.node) {
      throw new Error(result.error || `Figma returned ${result.status}.`);
    }

    const data = { fileName: result.fileName || null, node: result.node };
    nodeCache.set(cacheKey, { at: Date.now(), data });
    if (nodeCache.size > 20) nodeCache.delete(nodeCache.keys().next().value);
    return data;
  } finally {
    if (created && tab.id) chrome.tabs.remove(tab.id, () => void chrome.runtime.lastError);
  }
}

async function handleAuth(message) {
  const token = typeof message.authToken === 'string' && message.authToken ? message.authToken : null;
  const apiBase = normalizeBase(message.apiBase);
  const updates = { authToken: token };
  if (apiBase) updates.apiBase = apiBase;
  await chrome.storage.local.set(updates);
  return token ? { ok: true } : { ok: false, error: 'not_signed_in' };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') return false;

  if (message.type === 'BUILDRS_AUTH') {
    handleAuth(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message.type === 'FIGMA_SYNC') {
    syncNow().then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message.type === 'STATUS') {
    getSettings().then((settings) => sendResponse({
      ok: true,
      linked: Boolean(settings.authToken),
      apiBase: settings.apiBase,
      frontendBase: settings.frontendBase,
      helperSyncedAt: settings.helperSyncedAt,
      lastSyncError: settings.lastSyncError,
      fileCount: settings.fileCount,
    })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message.type === 'FIGMA_GET_FILE') {
    getFile(message.fileKey)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message.type === 'FIGMA_GET_NODE') {
    getNode(message.fileKey, message.nodeId)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message.type === 'FIGMA_PING') {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return true;
  }
  return false;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: SYNC_INTERVAL_MINUTES });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: SYNC_INTERVAL_MINUTES });
  syncNow();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) syncNow();
});
